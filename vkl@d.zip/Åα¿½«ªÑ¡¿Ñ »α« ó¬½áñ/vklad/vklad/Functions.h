#pragma once

int counting(int babki, double years2);
double returnProcent(int babki, double years2);
int countingEuro(int babki, double years2);
int countingDollar(int babki, double years2);
int countingForPensioners(int babki, double years2);
double returnProcentPensia(int babki, double years2);
int countingForPensionersEuro(int babki, double years2);
int countingForPensionersDollar(int babki, double years2);